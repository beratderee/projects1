/**
 * Bütçe Planlama Uygulaması - Veri Yönetimi ve Depolama Katmanı
 */

const CATEGORIES = {
  income: {
    maas: { name: 'Maaş', icon: 'wallet', color: '#10b981', bg: 'bg-emerald-50 text-emerald-600' },
    ek_gelir: { name: 'Ek Gelir & Prim', icon: 'badge-percent', color: '#06b6d4', bg: 'bg-cyan-50 text-cyan-600' },
    yatirim: { name: 'Yatırım Getirisi', icon: 'trending-up', color: '#8b5cf6', bg: 'bg-purple-50 text-purple-600' },
    serbest: { name: 'Freelance & Danışmanlık', icon: 'laptop', color: '#3b82f6', bg: 'bg-blue-50 text-blue-600' },
    diger_gelir: { name: 'Diğer Gelir', icon: 'coins', color: '#64748b', bg: 'bg-slate-50 text-slate-600' }
  },
  expense: {
    market: { name: 'Market & Mutfak', icon: 'shopping-cart', color: '#f59e0b', bg: 'bg-amber-50 text-amber-600' },
    kira_konut: { name: 'Kira & Konut', icon: 'home', color: '#ef4444', bg: 'bg-rose-50 text-rose-600' },
    fatura: { name: 'Faturalar & Abonelikler', icon: 'receipt', color: '#f97316', bg: 'bg-orange-50 text-orange-600' },
    ulasim: { name: 'Ulaşım & Yakıt', icon: 'car', color: '#06b6d4', bg: 'bg-cyan-50 text-cyan-600' },
    eglence: { name: 'Eğlence & Sosyal', icon: 'gamepad-2', color: '#ec4899', bg: 'bg-pink-50 text-pink-600' },
    saglik: { name: 'Sağlık & Bakım', icon: 'heart-pulse', color: '#14b8a6', bg: 'bg-teal-50 text-teal-600' },
    egitim: { name: 'Eğitim & Kurs', icon: 'graduation-cap', color: '#6366f1', bg: 'bg-indigo-50 text-indigo-600' },
    giyim: { name: 'Giyim & Alışveriş', icon: 'shopping-bag', color: '#a855f7', bg: 'bg-purple-50 text-purple-600' },
    diger_gider: { name: 'Diğer Giderler', icon: 'more-horizontal', color: '#94a3b8', bg: 'bg-slate-50 text-slate-600' }
  }
};

const STORAGE_KEYS = {
  INITIALIZED: 'antigravity_budget_initialized_v1',
  TRANSACTIONS: 'antigravity_budget_transactions_v1',
  BUDGETS: 'antigravity_budget_limits_v1',
  SAVINGS: 'antigravity_budget_savings_v1',
  SETTINGS: 'antigravity_budget_settings_v1'
};

// Varsayılan Bütçe Limitleri (Aylık)
const DEFAULT_BUDGETS = {
  market: 8500,
  kira_konut: 20000,
  fatura: 3500,
  ulasim: 3200,
  eglence: 2500,
  saglik: 2000,
  egitim: 2500,
  giyim: 3000,
  diger_gider: 2000
};

// Varsayılan Birikim Hedefleri
const DEFAULT_SAVINGS = [
  {
    id: 'goal-1',
    title: 'Acil Durum Fonu (6 Aylık)',
    target: 120000,
    current: 85000,
    deadline: '2026-12-31',
    color: '#10b981',
    icon: 'shield-check'
  },
  {
    id: 'goal-2',
    title: 'Yaz Tatili Planı',
    target: 40000,
    current: 28500,
    deadline: '2026-07-15',
    color: '#06b6d4',
    icon: 'palmtree'
  },
  {
    id: 'goal-3',
    title: 'Yeni Çalışma Bilgisayarı',
    target: 65000,
    current: 52000,
    deadline: '2026-11-30',
    color: '#8b5cf6',
    icon: 'laptop'
  }
];

// Tarih Formatlayıcı Yardımcıları
function getRelativeDateStr(daysOffset = 0, monthOffset = 0) {
  const d = new Date();
  if (monthOffset !== 0) {
    d.setMonth(d.getMonth() + monthOffset);
  }
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Örnek İşlemler (Mevcut ve önceki ay için gerçekçi veriler)
function generateDemoTransactions() {
  const today = new Date();
  const y = today.getFullYear();
  const m = String(today.getMonth() + 1).padStart(2, '0');
  const prevM = String(today.getMonth() === 0 ? 12 : today.getMonth()).padStart(2, '0');
  const prevY = today.getMonth() === 0 ? y - 1 : y;

  return [
    // Bu ayki işlemler
    {
      id: 'tx-1',
      type: 'income',
      amount: 54000,
      category: 'maas',
      title: 'Aylık Şirket Maaşı',
      date: `${y}-${m}-01`,
      paymentMethod: 'Banka Transferi',
      note: 'Ekim ayı hakedişi'
    },
    {
      id: 'tx-2',
      type: 'expense',
      amount: 19500,
      category: 'kira_konut',
      title: 'Ev Kirası & Aidat',
      date: `${y}-${m}-02`,
      paymentMethod: 'Havale / EFT',
      note: 'Kira ve site aidatı ödendi'
    },
    {
      id: 'tx-3',
      type: 'expense',
      amount: 2850,
      category: 'fatura',
      title: 'Elektrik, Su, Doğalgaz',
      date: `${y}-${m}-03`,
      paymentMethod: 'Otomatik Ödeme',
      note: 'Eylül-Ekim dönemi faturaları'
    },
    {
      id: 'tx-4',
      type: 'expense',
      amount: 3420,
      category: 'market',
      title: 'Haftalık Büyük Market Alışverişi',
      date: `${y}-${m}-04`,
      paymentMethod: 'Kredi Kartı',
      note: 'Migros & Kasap'
    },
    {
      id: 'tx-5',
      type: 'income',
      amount: 8500,
      category: 'serbest',
      title: 'Web Sitesi Geliştirme Danışmanlığı',
      date: `${y}-${m}-06`,
      paymentMethod: 'Banka Transferi',
      note: 'Yurtdışı freelance proje'
    },
    {
      id: 'tx-6',
      type: 'expense',
      amount: 1650,
      category: 'ulasim',
      title: 'Akaryakıt Depo Dolumu',
      date: `${y}-${m}-07`,
      paymentMethod: 'Kredi Kartı',
      note: 'Opet'
    },
    {
      id: 'tx-7',
      type: 'expense',
      amount: 1150,
      category: 'eglence',
      title: 'Konser Bileti ve Akşam Yemeği',
      date: `${y}-${m}-09`,
      paymentMethod: 'Kredi Kartı',
      note: 'Arkadaşlarla buluşma'
    },
    {
      id: 'tx-8',
      type: 'expense',
      amount: 2200,
      category: 'market',
      title: 'Organik Pazar ve Şarküteri',
      date: `${y}-${m}-11`,
      paymentMethod: 'Kredi Kartı',
      note: 'Haftalık taze sebze & meyve'
    },
    {
      id: 'tx-9',
      type: 'expense',
      amount: 850,
      category: 'saglik',
      title: 'Eczane & Vitamin Takviyeleri',
      date: `${y}-${m}-12`,
      paymentMethod: 'Nakit',
      note: 'Mevsimsel takviyeler'
    },
    {
      id: 'tx-10',
      type: 'expense',
      amount: 1800,
      category: 'giyim',
      title: 'Kışlık Mont ve Ayakkabı Bakımı',
      date: `${y}-${m}-13`,
      paymentMethod: 'Kredi Kartı',
      note: 'Zara & Boyner'
    },
    {
      id: 'tx-11',
      type: 'income',
      amount: 3200,
      category: 'yatirim',
      title: 'Fon & Hisse Temettü Geliri',
      date: `${y}-${m}-14`,
      paymentMethod: 'Banka Transferi',
      note: 'Portföy getirisi'
    },

    // Önceki ayki bazı işlemler (Trend grafikleri için)
    {
      id: 'tx-old-1',
      type: 'income',
      amount: 52000,
      category: 'maas',
      title: 'Önceki Ay Maaş',
      date: `${prevY}-${prevM}-01`,
      paymentMethod: 'Banka Transferi',
      note: 'Maaş ödemesi'
    },
    {
      id: 'tx-old-2',
      type: 'expense',
      amount: 19500,
      category: 'kira_konut',
      title: 'Ev Kirası',
      date: `${prevY}-${prevM}-02`,
      paymentMethod: 'Havale / EFT',
      note: 'Kira ödemesi'
    },
    {
      id: 'tx-old-3',
      type: 'expense',
      amount: 7200,
      category: 'market',
      title: 'Aylık Toplam Market',
      date: `${prevY}-${prevM}-15`,
      paymentMethod: 'Kredi Kartı',
      note: 'Önceki ay gıda toplamı'
    },
    {
      id: 'tx-old-4',
      type: 'expense',
      amount: 2900,
      category: 'ulasim',
      title: 'Aylık Ulaşım & Yakıt',
      date: `${prevY}-${prevM}-20`,
      paymentMethod: 'Kredi Kartı',
      note: 'Yakıt ve OGS'
    },
    {
      id: 'tx-old-5',
      type: 'income',
      amount: 6000,
      category: 'ek_gelir',
      title: 'Performans Primi',
      date: `${prevY}-${prevM}-25`,
      paymentMethod: 'Banka Transferi',
      note: 'Çeyrek prim ödemesi'
    }
  ];
}

// Veri Yönetim Sınıfı (DataManager)
class DataManager {
  static getTransactions() {
    const isInitialized = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    
    if (!isInitialized) {
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
      const initial = generateDemoTransactions();
      this.saveTransactions(initial);
      return initial;
    }

    if (!raw) {
      return [];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      console.error('İşlemler çözümlenemedi:', e);
      return [];
    }
  }

  static saveTransactions(transactions) {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }

  static addTransaction(tx) {
    const transactions = this.getTransactions();
    tx.id = 'tx-' + Date.now();
    transactions.unshift(tx);
    this.saveTransactions(transactions);
    return tx;
  }

  static deleteTransaction(id) {
    const transactions = this.getTransactions().filter(t => t.id !== id);
    this.saveTransactions(transactions);
    return transactions;
  }

  static updateTransaction(id, updatedData) {
    const transactions = this.getTransactions().map(t => {
      if (t.id === id) {
        return { ...t, ...updatedData };
      }
      return t;
    });
    this.saveTransactions(transactions);
    return transactions;
  }

  static getBudgets() {
    const raw = localStorage.getItem(STORAGE_KEYS.BUDGETS);
    if (!raw) {
      this.saveBudgets(DEFAULT_BUDGETS);
      return DEFAULT_BUDGETS;
    }
    try {
      return { ...DEFAULT_BUDGETS, ...JSON.parse(raw) };
    } catch (e) {
      return DEFAULT_BUDGETS;
    }
  }

  static saveBudgets(budgets) {
    localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
  }

  static setBudget(categoryKey, amount) {
    const budgets = this.getBudgets();
    budgets[categoryKey] = Number(amount);
    this.saveBudgets(budgets);
    return budgets;
  }

  static getSavings() {
    const raw = localStorage.getItem(STORAGE_KEYS.SAVINGS);
    if (!raw) {
      this.saveSavings(DEFAULT_SAVINGS);
      return DEFAULT_SAVINGS;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return DEFAULT_SAVINGS;
    }
  }

  static saveSavings(savings) {
    localStorage.setItem(STORAGE_KEYS.SAVINGS, JSON.stringify(savings));
  }

  static addSavingsGoal(goal) {
    const savings = this.getSavings();
    goal.id = 'goal-' + Date.now();
    goal.current = Number(goal.current) || 0;
    goal.target = Number(goal.target) || 1000;
    savings.push(goal);
    this.saveSavings(savings);
    return goal;
  }

  static updateSavingsAmount(id, deltaAmount) {
    const savings = this.getSavings();
    const goal = savings.find(g => g.id === id);
    if (goal) {
      goal.current = Math.max(0, goal.current + Number(deltaAmount));
      this.saveSavings(savings);
      return goal;
    }
    return null;
  }

  static deleteSavingsGoal(id) {
    const savings = this.getSavings().filter(g => g.id !== id);
    this.saveSavings(savings);
    return savings;
  }

  static resetToDefaults() {
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    const demoTxs = generateDemoTransactions();
    this.saveTransactions(demoTxs);
    this.saveBudgets(DEFAULT_BUDGETS);
    this.saveSavings(DEFAULT_SAVINGS);
    return true;
  }

  static clearAllData() {
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    this.saveTransactions([]);
    this.saveSavings([]);
    this.saveBudgets(DEFAULT_BUDGETS);
  }

  static clearTransactionsOnly() {
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    this.saveTransactions([]);
  }

  // Yedek Dışa Aktarma (JSON)
  static exportJSON() {
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      transactions: this.getTransactions(),
      budgets: this.getBudgets(),
      savings: this.getSavings()
    };
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `butce_yedek_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Excel Uyumlu CSV Dışa Aktarma (UTF-8 BOM ile Türkçe karakter desteği)
  static exportCSV() {
    const transactions = this.getTransactions();
    const headers = ['Tarih', 'Tür', 'Kategori', 'Açıklama', 'Tutar (TL)', 'Ödeme Yöntemi', 'Not'];
    
    const rows = transactions.map(t => {
      const typeLabel = t.type === 'income' ? 'Gelir' : 'Gider';
      const catObj = (t.type === 'income' ? CATEGORIES.income : CATEGORIES.expense)[t.category];
      const catLabel = catObj ? catObj.name : t.category;
      
      return [
        t.date || '',
        typeLabel,
        `"${catLabel}"`,
        `"${(t.title || '').replace(/"/g, '""')}"`,
        t.amount,
        `"${t.paymentMethod || ''}"`,
        `"${(t.note || '').replace(/"/g, '""')}"`
      ].join(';');
    });

    const csvContent = '\uFEFF' + [headers.join(';'), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `butce_hareketleri_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // JSON Yedeğini İçe Aktarma
  static importJSON(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (!data || !Array.isArray(data.transactions)) {
        throw new Error('Geçersiz yedek dosyası formatı.');
      }
      if (data.transactions) this.saveTransactions(data.transactions);
      if (data.budgets) this.saveBudgets(data.budgets);
      if (data.savings) this.saveSavings(data.savings);
      return { success: true, count: data.transactions.length };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}

// Para ve Tarih Formatlama Fonksiyonları
function formatCurrency(amount) {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(num);
}

function formatDate(dateString) {
  if (!dateString) return '-';
  const parts = dateString.split('-');
  if (parts.length === 3) {
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    return d.toLocaleDateString('tr-TR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  }
  return dateString;
}

function getCategoryInfo(type, catKey) {
  const group = type === 'income' ? CATEGORIES.income : CATEGORIES.expense;
  return group[catKey] || {
    name: catKey,
    icon: 'circle',
    color: '#64748b',
    bg: 'bg-slate-100 text-slate-700'
  };
}
