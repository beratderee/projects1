/**
 * Bütçe Planlama Uygulaması - Ana Kontrolör (App)
 */

class App {
  static currentTab = 'dashboard';
  static currentTxType = 'expense';
  static currentDepositAction = 'add';

  static init() {
    // Mobil menü dinleyicileri
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mobileDrawer = document.getElementById('mobile-drawer');
    const closeMobileBtn = document.getElementById('close-mobile-menu');

    if (mobileBtn && mobileDrawer) {
      mobileBtn.addEventListener('click', () => {
        mobileDrawer.classList.remove('hidden');
      });
    }
    if (closeMobileBtn && mobileDrawer) {
      closeMobileBtn.addEventListener('click', () => {
        mobileDrawer.classList.add('hidden');
      });
    }

    // Ay başlığı ve etiketi
    const today = new Date();
    const monthNames = [
      'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
      'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
    ];
    const monthBadge = document.getElementById('current-month-badge');
    if (monthBadge) {
      monthBadge.innerText = `${monthNames[today.getMonth()]} ${today.getFullYear()}`;
    }

    // Tarih inputu varsayılan bugünün tarihi
    const todayStr = today.toISOString().split('T')[0];
    const dateInput = document.getElementById('tx-date-input');
    if (dateInput) {
      dateInput.value = todayStr;
    }

    // Filtre kategorilerini doldur
    this.populateFilterCategories();

    // Form kategorilerini ilk tür (gider) için doldur
    this.updateFormCategories('expense');

    // Varsayılan görünümü tazele
    this.refreshAll();

    // İkonları başlat
    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  static closeMobileMenu() {
    const mobileDrawer = document.getElementById('mobile-drawer');
    if (mobileDrawer) {
      mobileDrawer.classList.add('hidden');
    }
  }

  // Sekmeler Arası Geçiş
  static switchTab(tabId) {
    this.currentTab = tabId;

    // Sekme butonlarını güncelle
    document.querySelectorAll('.nav-tab').forEach(btn => {
      if (btn.getAttribute('data-tab') === tabId) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Görünümleri gizle / göster
    document.querySelectorAll('.tab-view').forEach(view => {
      view.classList.add('hidden');
    });

    const activeView = document.getElementById(`view-${tabId}`);
    if (activeView) {
      activeView.classList.remove('hidden');
    }

    // Başlıkları güncelle
    const titles = {
      dashboard: { title: 'Finansal Genel Bakış', subtitle: 'Gelir, gider ve tasarruf hedeflerinizi anlık olarak izleyin.' },
      transactions: { title: 'Gelir & Gider Hareketleri', subtitle: 'Tüm finansal işlemlerinizi detaylı olarak inceleyin, arayın ve filtreleyin.' },
      budgets: { title: 'Kategori Bütçe Limitleri', subtitle: 'Harcama tavanları koyarak gereksiz giderlerin önüne geçin.' },
      savings: { title: 'Birikim ve Gelecek Hedefleri', subtitle: 'Tasarruf hedeflerinize kalan tutarı ve ilerleme yüzdenizi görün.' },
      reports: { title: 'Finansal Raporlar & Analiz', subtitle: 'Harcama dağılımları ve aylık nakit akışı istatistikleri.' },
      settings: { title: 'Veri & Yedekleme Ayarları', subtitle: 'Verilerinizi dışa aktarın, yedekten geri yükleyin ya da sıfırlayın.' }
    };

    if (titles[tabId]) {
      const pageTitle = document.getElementById('page-title');
      const pageSubtitle = document.getElementById('page-subtitle');
      if (pageTitle) pageTitle.innerText = titles[tabId].title;
      if (pageSubtitle) pageSubtitle.innerText = titles[tabId].subtitle;
    }

    this.refreshCurrentTab();

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  static refreshAll() {
    this.refreshDashboard();
    this.refreshTransactions();
    this.refreshBudgets();
    this.refreshSavings();
    this.refreshReports();
  }

  static refreshCurrentTab() {
    switch (this.currentTab) {
      case 'dashboard':
        this.refreshDashboard();
        break;
      case 'transactions':
        this.refreshTransactions();
        break;
      case 'budgets':
        this.refreshBudgets();
        break;
      case 'savings':
        this.refreshSavings();
        break;
      case 'reports':
        this.refreshReports();
        break;
    }
  }

  // 1. GENEL BAKIŞ VERİLERİNİ GÜNCELLE
  static refreshDashboard() {
    const transactions = DataManager.getTransactions();
    const budgets = DataManager.getBudgets();

    const today = new Date();
    const curYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;

    // Bu ayki işlemler
    const monthTxs = transactions.filter(t => t.date && t.date.startsWith(curYearMonth));
    const monthIncome = monthTxs.filter(t => t.type === 'income').reduce((sum, t) => sum + Number(t.amount), 0);
    const monthExpense = monthTxs.filter(t => t.type === 'expense').reduce((sum, t) => sum + Number(t.amount), 0);
    const netBalance = monthIncome - monthExpense;

    // Metrik kartları
    const netBalanceEl = document.getElementById('stat-net-balance');
    const netStatusEl = document.getElementById('stat-net-status');
    const monthIncomeEl = document.getElementById('stat-month-income');
    const incomeCountEl = document.getElementById('stat-income-count');
    const monthExpenseEl = document.getElementById('stat-month-expense');
    const expenseRatioEl = document.getElementById('stat-expense-ratio');
    const savingsRateEl = document.getElementById('stat-savings-rate');
    const savingsProgressEl = document.getElementById('stat-savings-progress');

    if (netBalanceEl) {
      netBalanceEl.innerText = formatCurrency(netBalance);
      if (netBalance >= 0) {
        netBalanceEl.className = 'text-2xl font-extrabold text-slate-900';
        if (netStatusEl) {
          netStatusEl.innerHTML = `<i data-lucide="trending-up" class="w-3.5 h-3.5"></i> Pozitif Nakit Akışı`;
          netStatusEl.className = 'font-medium text-emerald-600 flex items-center gap-0.5';
        }
      } else {
        netBalanceEl.className = 'text-2xl font-extrabold text-rose-600';
        if (netStatusEl) {
          netStatusEl.innerHTML = `<i data-lucide="trending-down" class="w-3.5 h-3.5"></i> Bütçe Açığı (Gider Fazla)`;
          netStatusEl.className = 'font-medium text-rose-600 flex items-center gap-0.5';
        }
      }
    }

    if (monthIncomeEl) monthIncomeEl.innerText = formatCurrency(monthIncome);
    if (incomeCountEl) {
      const incCount = monthTxs.filter(t => t.type === 'income').length;
      incomeCountEl.innerText = `${incCount} gelir işlemi`;
    }

    if (monthExpenseEl) monthExpenseEl.innerText = formatCurrency(monthExpense);
    if (expenseRatioEl) {
      const ratio = monthIncome > 0 ? Math.round((monthExpense / monthIncome) * 100) : 0;
      expenseRatioEl.innerText = `Gelirin %${ratio}'i harcandı`;
    }

    if (savingsRateEl && savingsProgressEl) {
      const rate = monthIncome > 0 ? Math.max(0, Math.round(((monthIncome - monthExpense) / monthIncome) * 100)) : 0;
      savingsRateEl.innerText = `%${rate}`;
      savingsProgressEl.style.width = `${Math.min(100, rate)}%`;
      if (rate >= 20) {
        savingsProgressEl.className = 'bg-emerald-500 h-1.5 rounded-full transition-all duration-500';
      } else if (rate > 0) {
        savingsProgressEl.className = 'bg-amber-500 h-1.5 rounded-full transition-all duration-500';
      } else {
        savingsProgressEl.className = 'bg-rose-500 h-1.5 rounded-full transition-all duration-500';
      }
    }

    // Harcama Dağılımı ve Trend Grafikleri
    ChartManager.renderExpenseDonut('expenseDonutCanvas', monthTxs);
    ChartManager.renderMonthlyTrend('monthlyTrendCanvas', transactions);

    // Kategori Harcamaları ve Aşım Kontrolleri
    const categoryExpenses = {};
    monthTxs.filter(t => t.type === 'expense').forEach(t => {
      categoryExpenses[t.category] = (categoryExpenses[t.category] || 0) + Number(t.amount);
    });

    const exceededCategories = [];
    const warningCategories = [];

    Object.keys(budgets).forEach(cat => {
      const spent = categoryExpenses[cat] || 0;
      const limit = budgets[cat] || 0;
      if (limit > 0) {
        if (spent > limit) {
          exceededCategories.push({ cat, spent, limit });
        } else if (spent >= limit * 0.85) {
          warningCategories.push({ cat, spent, limit });
        }
      }
    });

    // Aşım Bannerı
    const alertBanner = document.getElementById('budget-alert-banner');
    const alertDesc = document.getElementById('budget-alert-desc');
    if (alertBanner && alertDesc) {
      if (exceededCategories.length > 0) {
        alertBanner.classList.remove('hidden');
        const names = exceededCategories.map(c => CATEGORIES.expense[c.cat]?.name || c.cat).join(', ');
        alertDesc.innerText = `Bütçe limiti aşılan kategoriler: ${names}`;
      } else if (warningCategories.length > 0) {
        alertBanner.classList.remove('hidden');
        const names = warningCategories.map(c => CATEGORIES.expense[c.cat]?.name || c.cat).join(', ');
        alertDesc.innerText = `Limite yaklaşan kategoriler (%85+): ${names}`;
      } else {
        alertBanner.classList.add('hidden');
      }
    }

    // Dashboard Bütçe Listesi (En çok harcanan ilk 4 kategori)
    const budgetListContainer = document.getElementById('dashboard-budget-list');
    if (budgetListContainer) {
      const budgetItems = Object.keys(budgets).map(cat => ({
        cat,
        spent: categoryExpenses[cat] || 0,
        limit: budgets[cat] || 0,
        pct: (budgets[cat] > 0) ? Math.round(((categoryExpenses[cat] || 0) / budgets[cat]) * 100) : 0
      })).sort((a, b) => b.pct - a.pct).slice(0, 4);

      if (budgetItems.length === 0) {
        budgetListContainer.innerHTML = `<p class="text-xs text-slate-400 py-4 text-center">Bütçe bilgisi bulunamadı.</p>`;
      } else {
        budgetListContainer.innerHTML = budgetItems.map(item => {
          const info = CATEGORIES.expense[item.cat] || { name: item.cat, icon: 'tag' };
          let barColor = 'bg-indigo-600';
          let statusBadge = `<span class="text-[11px] font-semibold text-slate-500">%${item.pct}</span>`;

          if (item.pct > 100) {
            barColor = 'bg-rose-600';
            statusBadge = `<span class="px-2 py-0.5 text-[10px] font-bold bg-rose-100 text-rose-700 rounded-full badge-exceeded">Aşıldı! (%${item.pct})</span>`;
          } else if (item.pct >= 85) {
            barColor = 'bg-amber-500';
            statusBadge = `<span class="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-700 rounded-full">Kritik (%${item.pct})</span>`;
          }

          return `
            <div class="space-y-1.5">
              <div class="flex items-center justify-between text-xs">
                <div class="flex items-center gap-2">
                  <span class="font-semibold text-slate-800">${info.name}</span>
                </div>
                <div class="flex items-center gap-2">
                  <span class="text-slate-500">${formatCurrency(item.spent)} / ${formatCurrency(item.limit)}</span>
                  ${statusBadge}
                </div>
              </div>
              <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div class="${barColor} h-2 rounded-full transition-all duration-500" style="width: ${Math.min(100, item.pct)}%"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Dashboard Son İşlemler (Son 5 işlem)
    const recentTxContainer = document.getElementById('dashboard-recent-transactions');
    if (recentTxContainer) {
      const recent = transactions.slice(0, 5);
      if (recent.length === 0) {
        recentTxContainer.innerHTML = `<p class="text-xs text-slate-400 py-6 text-center">Henüz işlem kaydedilmedi.</p>`;
      } else {
        recentTxContainer.innerHTML = recent.map(t => {
          const isIncome = t.type === 'income';
          const catInfo = getCategoryInfo(t.type, t.category);
          const sign = isIncome ? '+' : '-';
          const amountClass = isIncome ? 'text-emerald-600 font-bold' : 'text-slate-900 font-bold';

          return `
            <div class="py-3 flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl ${catInfo.bg} flex items-center justify-center shrink-0">
                  <i data-lucide="${catInfo.icon}" class="w-4 h-4"></i>
                </div>
                <div>
                  <h4 class="text-sm font-semibold text-slate-800 leading-tight">${t.title || catInfo.name}</h4>
                  <div class="flex items-center gap-2 mt-0.5">
                    <span class="text-[11px] text-slate-400">${formatDate(t.date)}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">${catInfo.name}</span>
                  </div>
                </div>
              </div>
              <div class="text-right">
                <span class="text-sm ${amountClass}">${sign}${formatCurrency(t.amount)}</span>
                <p class="text-[10px] text-slate-400">${t.paymentMethod || ''}</p>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  // 2. GELİR & GİDERLER TABLOSUNU GÜNCELLE
  static filterTransactions() {
    this.refreshTransactions();
  }

  static refreshTransactions() {
    const transactions = DataManager.getTransactions();
    const searchInput = document.getElementById('tx-search-input');
    const filterType = document.getElementById('tx-filter-type');
    const filterCat = document.getElementById('tx-filter-category');
    const filterPeriod = document.getElementById('tx-filter-period');

    const searchVal = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const typeVal = filterType ? filterType.value : 'all';
    const catVal = filterCat ? filterCat.value : 'all';
    const periodVal = filterPeriod ? filterPeriod.value : 'this_month';

    const today = new Date();
    const curYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const prevM = String(today.getMonth() === 0 ? 12 : today.getMonth()).padStart(2, '0');
    const prevY = today.getMonth() === 0 ? today.getFullYear() - 1 : today.getFullYear();
    const prevYearMonth = `${prevY}-${prevM}`;

    const filtered = transactions.filter(t => {
      // Metin Arama
      if (searchVal) {
        const titleMatch = (t.title || '').toLowerCase().includes(searchVal);
        const noteMatch = (t.note || '').toLowerCase().includes(searchVal);
        const catObj = getCategoryInfo(t.type, t.category);
        const catMatch = (catObj.name || '').toLowerCase().includes(searchVal);
        if (!titleMatch && !noteMatch && !catMatch) return false;
      }

      // Tür Filtresi
      if (typeVal !== 'all' && t.type !== typeVal) return false;

      // Kategori Filtresi
      if (catVal !== 'all' && t.category !== catVal) return false;

      // Dönem Filtresi
      if (periodVal === 'this_month') {
        if (!t.date || !t.date.startsWith(curYearMonth)) return false;
      } else if (periodVal === 'last_month') {
        if (!t.date || !t.date.startsWith(prevYearMonth)) return false;
      }

      return true;
    });

    // Tablo Satırlarını Oluştur
    const tableBody = document.getElementById('transaction-table-body');
    const countLabel = document.getElementById('tx-count-label');
    const totalIncomeEl = document.getElementById('filtered-total-income');
    const totalExpenseEl = document.getElementById('filtered-total-expense');
    const netDiffEl = document.getElementById('filtered-net-diff');

    let sumIncome = 0;
    let sumExpense = 0;

    filtered.forEach(t => {
      if (t.type === 'income') sumIncome += Number(t.amount);
      else sumExpense += Number(t.amount);
    });

    if (countLabel) countLabel.innerText = `${filtered.length} işlem listelendi`;
    if (totalIncomeEl) totalIncomeEl.innerText = formatCurrency(sumIncome);
    if (totalExpenseEl) totalExpenseEl.innerText = formatCurrency(sumExpense);
    if (netDiffEl) {
      const diff = sumIncome - sumExpense;
      netDiffEl.innerText = formatCurrency(diff);
      netDiffEl.className = diff >= 0 ? 'text-emerald-700' : 'text-rose-700';
    }

    if (!tableBody) return;

    if (filtered.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6" class="py-12 text-center text-slate-400 text-sm">
            <i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
            Kriterlere uygun herhangi bir işlem bulunamadı.
          </td>
        </tr>
      `;
    } else {
      tableBody.innerHTML = filtered.map(t => {
        const isIncome = t.type === 'income';
        const catInfo = getCategoryInfo(t.type, t.category);
        const sign = isIncome ? '+' : '-';
        const amountClass = isIncome ? 'text-emerald-600 font-bold' : 'text-slate-800 font-bold';

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="py-3 px-5 text-slate-500 whitespace-nowrap text-xs">
              ${formatDate(t.date)}
            </td>
            <td class="py-3 px-5 font-medium text-slate-800">
              <div class="font-semibold">${t.title || catInfo.name}</div>
              ${t.note ? `<div class="text-[11px] text-slate-400">${t.note}</div>` : ''}
            </td>
            <td class="py-3 px-5 whitespace-nowrap">
              <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold ${catInfo.bg}">
                <i data-lucide="${catInfo.icon}" class="w-3.5 h-3.5"></i>
                ${catInfo.name}
              </span>
            </td>
            <td class="py-3 px-5 text-slate-500 text-xs whitespace-nowrap">
              ${t.paymentMethod || 'Belirtilmedi'}
            </td>
            <td class="py-3 px-5 text-right whitespace-nowrap ${amountClass}">
              ${sign}${formatCurrency(t.amount)}
            </td>
            <td class="py-3 px-5 text-center whitespace-nowrap">
              <div class="flex items-center justify-center gap-1">
                <button onclick="App.editTransaction('${t.id}')" title="Düzenle" class="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition">
                  <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                </button>
                <button onclick="App.deleteTransactionConfirm('${t.id}')" title="Sil" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition">
                  <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  // 3. BÜTÇE LİMİTLERİNİ GÜNCELLE
  static refreshBudgets() {
    const budgets = DataManager.getBudgets();
    const transactions = DataManager.getTransactions();

    const today = new Date();
    const curYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const monthExpenses = transactions.filter(t => t.type === 'expense' && t.date && t.date.startsWith(curYearMonth));

    const categoryExpenses = {};
    monthExpenses.forEach(t => {
      categoryExpenses[t.category] = (categoryExpenses[t.category] || 0) + Number(t.amount);
    });

    const grid = document.getElementById('budgets-card-grid');
    if (grid) {
      grid.innerHTML = Object.keys(CATEGORIES.expense).map(catKey => {
        const catInfo = CATEGORIES.expense[catKey];
        const limit = budgets[catKey] || 0;
        const spent = categoryExpenses[catKey] || 0;
        const remaining = Math.max(0, limit - spent);
        const pct = limit > 0 ? Math.round((spent / limit) * 100) : 0;

        let statusClass = 'text-slate-500';
        let barColor = 'bg-indigo-600';
        let statusBadge = '';

        if (pct > 100) {
          statusClass = 'text-rose-600 font-bold';
          barColor = 'bg-rose-600 progress-striped';
          statusBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700 badge-exceeded">Aşım: +${formatCurrency(spent - limit)}</span>`;
        } else if (pct >= 85) {
          statusClass = 'text-amber-600 font-bold';
          barColor = 'bg-amber-500';
          statusBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">%${pct} Kullanıldı</span>`;
        } else {
          statusBadge = `<span class="text-xs text-slate-400">%${pct}</span>`;
        }

        return `
          <div class="soft-card p-5 rounded-2xl flex flex-col justify-between space-y-4">
            <div>
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                  <div class="w-10 h-10 rounded-xl ${catInfo.bg} flex items-center justify-center">
                    <i data-lucide="${catInfo.icon}" class="w-5 h-5"></i>
                  </div>
                  <div>
                    <h4 class="font-bold text-slate-900 text-sm">${catInfo.name}</h4>
                    <p class="text-[11px] text-slate-400">Aylık Limit: ${formatCurrency(limit)}</p>
                  </div>
                </div>
                ${statusBadge}
              </div>

              <!-- İlerleme Çubuğu -->
              <div class="mt-4 space-y-1.5">
                <div class="flex items-center justify-between text-xs font-semibold">
                  <span class="text-slate-700">Harcanan: ${formatCurrency(spent)}</span>
                  <span class="${statusClass}">${spent > limit ? 'Bütçe Aşıldı!' : `${formatCurrency(remaining)} kaldı`}</span>
                </div>
                <div class="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div class="${barColor} h-2.5 rounded-full transition-all duration-500" style="width: ${Math.min(100, pct)}%"></div>
                </div>
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 flex items-center justify-end">
              <button onclick="App.openEditBudgetModal('${catKey}')" class="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                <i data-lucide="edit-3" class="w-3.5 h-3.5"></i> Limiti Değiştir
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    // Bütçe vs Harcanan Grafiği
    ChartManager.renderBudgetComparison('budgetComparisonCanvas', budgets, categoryExpenses);

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  // 4. BİRİKİM HEDEFLERİNİ GÜNCELLE
  static refreshSavings() {
    const savings = DataManager.getSavings();
    const grid = document.getElementById('savings-grid');
    if (!grid) return;

    if (savings.length === 0) {
      grid.innerHTML = `
        <div class="col-span-full py-16 text-center text-slate-400">
          <i data-lucide="target" class="w-12 h-12 mx-auto mb-3 opacity-30"></i>
          <h4 class="text-base font-bold text-slate-600">Henüz Birikim Hedefi Eklenmedi</h4>
          <p class="text-xs text-slate-400 mt-1">Tatil, acil durum veya teknoloji hedefleriniz için birikim başlatın.</p>
          <button onclick="App.openAddSavingsModal()" class="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md">
            + İlk Hedefi Ekle
          </button>
        </div>
      `;
    } else {
      grid.innerHTML = savings.map(goal => {
        const pct = goal.target > 0 ? Math.min(100, Math.round((goal.current / goal.target) * 100)) : 0;
        const remaining = Math.max(0, goal.target - goal.current);
        const isCompleted = goal.current >= goal.target;

        // Hedef tarih kalan gün hesabı
        let daysLeftText = '';
        if (goal.deadline) {
          const deadlineDate = new Date(goal.deadline);
          const now = new Date();
          const diffTime = deadlineDate - now;
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          if (diffDays > 0) {
            daysLeftText = `${diffDays} gün kaldı`;
          } else if (diffDays === 0) {
            daysLeftText = `Bugün son gün!`;
          } else {
            daysLeftText = `Süre tamamlandı`;
          }
        }

        return `
          <div class="soft-card p-5 rounded-2xl flex flex-col justify-between space-y-4 relative overflow-hidden">
            ${isCompleted ? `
              <div class="absolute top-0 right-0 bg-emerald-500 text-white text-[10px] font-extrabold px-3 py-1 rounded-bl-xl shadow-sm flex items-center gap-1">
                <i data-lucide="check-circle" class="w-3 h-3"></i> TAMAMLANDI!
              </div>
            ` : ''}

            <div>
              <div class="flex items-start justify-between">
                <div class="pr-6">
                  <h4 class="font-bold text-slate-900 text-base leading-snug">${goal.title}</h4>
                  <div class="flex items-center gap-2 mt-1 text-xs text-slate-400">
                    <span class="flex items-center gap-1"><i data-lucide="calendar" class="w-3.5 h-3.5"></i> ${formatDate(goal.deadline)}</span>
                    <span>•</span>
                    <span class="text-indigo-600 font-medium">${daysLeftText}</span>
                  </div>
                </div>
                <button onclick="App.deleteSavingsGoalConfirm('${goal.id}')" title="Hedefi Sil" class="text-slate-300 hover:text-rose-500 p-1">
                  <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
              </div>

              <!-- İlerleme Çubuğu ve Tutarlar -->
              <div class="mt-5 space-y-2">
                <div class="flex items-baseline justify-between">
                  <div>
                    <span class="text-2xl font-black text-slate-900">${formatCurrency(goal.current)}</span>
                    <span class="text-xs text-slate-400">/ ${formatCurrency(goal.target)}</span>
                  </div>
                  <span class="text-base font-extrabold text-indigo-600">%${pct}</span>
                </div>

                <div class="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5">
                  <div class="bg-gradient-to-r from-indigo-500 to-emerald-500 h-2 rounded-full transition-all duration-500" style="width: ${pct}%"></div>
                </div>

                <div class="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>Hedefe Kalan: <b>${formatCurrency(remaining)}</b></span>
                  ${isCompleted ? '<span class="text-emerald-600 font-bold">Tebrikler! 🎉</span>' : ''}
                </div>
              </div>
            </div>

            <!-- Para Ekle / Çıkar Aksiyonları -->
            <div class="pt-3 border-t border-slate-100 flex items-center gap-2">
              <button onclick="App.openDepositModal('${goal.id}', 'add')" class="flex-1 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1">
                <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i> Para Ekle
              </button>
              <button onclick="App.openDepositModal('${goal.id}', 'sub')" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold rounded-xl text-xs transition" title="Para Çek">
                <i data-lucide="minus" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  // 5. RAPORLAR & ANALİZ GÜNCELLE
  static refreshReports() {
    const transactions = DataManager.getTransactions();
    const today = new Date();
    const curYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const monthExpenses = transactions.filter(t => t.type === 'expense' && t.date && t.date.startsWith(curYearMonth));

    // Günlük ortalama
    const dayOfMonth = today.getDate();
    const totalMonthExp = monthExpenses.reduce((s, t) => s + Number(t.amount), 0);
    const dailyAvg = dayOfMonth > 0 ? (totalMonthExp / dayOfMonth) : 0;

    const dailyAvgEl = document.getElementById('report-daily-avg');
    if (dailyAvgEl) dailyAvgEl.innerText = formatCurrency(dailyAvg);

    // En yüksek tekil harcama
    const maxExpEl = document.getElementById('report-max-expense');
    const maxExpTitleEl = document.getElementById('report-max-expense-title');
    if (monthExpenses.length > 0) {
      const sortedByAmount = [...monthExpenses].sort((a, b) => b.amount - a.amount);
      const topExp = sortedByAmount[0];
      if (maxExpEl) maxExpEl.innerText = formatCurrency(topExp.amount);
      if (maxExpTitleEl) maxExpTitleEl.innerText = `${topExp.title} (${formatDate(topExp.date)})`;
    } else {
      if (maxExpEl) maxExpEl.innerText = '0,00 ₺';
      if (maxExpTitleEl) maxExpTitleEl.innerText = 'Bu ay henüz harcama yok';
    }

    // En çok harcanan kategori
    const catTotals = {};
    monthExpenses.forEach(t => {
      catTotals[t.category] = (catTotals[t.category] || 0) + Number(t.amount);
    });

    const sortedCats = Object.keys(catTotals).sort((a, b) => catTotals[b] - catTotals[a]);
    const topCatEl = document.getElementById('report-top-category');
    const topCatAmountEl = document.getElementById('report-top-category-amount');

    if (sortedCats.length > 0) {
      const topCat = sortedCats[0];
      const info = CATEGORIES.expense[topCat];
      if (topCatEl) topCatEl.innerText = info ? info.name : topCat;
      if (topCatAmountEl) topCatAmountEl.innerText = formatCurrency(catTotals[topCat]);
    } else {
      if (topCatEl) topCatEl.innerText = '-';
      if (topCatAmountEl) topCatAmountEl.innerText = '0,00 ₺';
    }

    // Kategori Sıralaması
    const rankingContainer = document.getElementById('report-category-ranking');
    if (rankingContainer) {
      if (sortedCats.length === 0) {
        rankingContainer.innerHTML = `<p class="text-xs text-slate-400 py-4 text-center">Bu ay henüz harcama kaydı yok.</p>`;
      } else {
        rankingContainer.innerHTML = sortedCats.map((catKey, index) => {
          const info = CATEGORIES.expense[catKey] || { name: catKey, icon: 'tag', bg: 'bg-slate-100 text-slate-600' };
          const amount = catTotals[catKey];
          const pct = totalMonthExp > 0 ? Math.round((amount / totalMonthExp) * 100) : 0;

          return `
            <div class="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div class="flex items-center gap-3">
                <span class="w-6 text-center font-black text-slate-400 text-sm">#${index + 1}</span>
                <div class="w-8 h-8 rounded-lg ${info.bg} flex items-center justify-center">
                  <i data-lucide="${info.icon}" class="w-4 h-4"></i>
                </div>
                <span class="font-bold text-slate-800 text-sm">${info.name}</span>
              </div>
              <div class="text-right">
                <div class="font-extrabold text-slate-900 text-sm">${formatCurrency(amount)}</div>
                <div class="text-[11px] text-slate-400">Toplam giderin %${pct}'i</div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
  }

  // MODAL VE FORM FONKSİYONLARI

  // İşlem Formu Kategorilerini Güncelle
  static updateFormCategories(type) {
    const select = document.getElementById('tx-category-select');
    if (!select) return;

    const group = type === 'income' ? CATEGORIES.income : CATEGORIES.expense;
    select.innerHTML = Object.keys(group).map(key => {
      return `<option value="${key}">${group[key].name}</option>`;
    }).join('');
  }

  static populateFilterCategories() {
    const filterCat = document.getElementById('tx-filter-category');
    if (!filterCat) return;

    let html = `<option value="all">Tüm Kategoriler</option>`;
    html += `<optgroup label="Giderler">`;
    Object.keys(CATEGORIES.expense).forEach(k => {
      html += `<option value="${k}">${CATEGORIES.expense[k].name}</option>`;
    });
    html += `</optgroup>`;
    html += `<optgroup label="Gelirler">`;
    Object.keys(CATEGORIES.income).forEach(k => {
      html += `<option value="${k}">${CATEGORIES.income[k].name}</option>`;
    });
    html += `</optgroup>`;

    filterCat.innerHTML = html;
  }

  static setFormTxType(type) {
    this.currentTxType = type;
    const typeInput = document.getElementById('tx-type-input');
    const btnExpense = document.getElementById('tx-btn-type-expense');
    const btnIncome = document.getElementById('tx-btn-type-income');

    if (typeInput) typeInput.value = type;

    if (type === 'expense') {
      btnExpense.className = 'py-2 rounded-lg text-xs font-bold transition bg-white text-rose-600 shadow-sm';
      btnIncome.className = 'py-2 rounded-lg text-xs font-bold transition text-slate-600 hover:text-slate-900';
    } else {
      btnIncome.className = 'py-2 rounded-lg text-xs font-bold transition bg-white text-emerald-600 shadow-sm';
      btnExpense.className = 'py-2 rounded-lg text-xs font-bold transition text-slate-600 hover:text-slate-900';
    }

    this.updateFormCategories(type);
  }

  static openAddTransactionModal() {
    const modal = document.getElementById('modal-transaction');
    const form = document.getElementById('tx-form');
    const titleEl = document.getElementById('modal-tx-title');
    const editId = document.getElementById('tx-edit-id');

    if (form) form.reset();
    if (editId) editId.value = '';
    if (titleEl) titleEl.innerText = 'Yeni İşlem Kaydet';

    this.setFormTxType('expense');

    const todayStr = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('tx-date-input');
    if (dateInput) dateInput.value = todayStr;

    if (modal) modal.classList.remove('hidden');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }

  static editTransaction(id) {
    const transactions = DataManager.getTransactions();
    const tx = transactions.find(t => t.id === id);
    if (!tx) return;

    const modal = document.getElementById('modal-transaction');
    const titleEl = document.getElementById('modal-tx-title');
    const editId = document.getElementById('tx-edit-id');

    if (titleEl) titleEl.innerText = 'İşlemi Düzenle';
    if (editId) editId.value = tx.id;

    this.setFormTxType(tx.type);

    document.getElementById('tx-amount-input').value = tx.amount;
    document.getElementById('tx-title-input').value = tx.title || '';
    document.getElementById('tx-category-select').value = tx.category;
    document.getElementById('tx-date-input').value = tx.date;
    document.getElementById('tx-payment-method').value = tx.paymentMethod || 'Kredi Kartı';
    document.getElementById('tx-note-input').value = tx.note || '';

    if (modal) modal.classList.remove('hidden');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }

  static closeTransactionModal() {
    const modal = document.getElementById('modal-transaction');
    if (modal) modal.classList.add('hidden');
  }

  static saveTransaction(e) {
    e.preventDefault();
    const editId = document.getElementById('tx-edit-id').value;
    const type = document.getElementById('tx-type-input').value;
    const amount = Number(document.getElementById('tx-amount-input').value);
    const title = document.getElementById('tx-title-input').value.trim();
    const category = document.getElementById('tx-category-select').value;
    const date = document.getElementById('tx-date-input').value;
    const paymentMethod = document.getElementById('tx-payment-method').value;
    const note = document.getElementById('tx-note-input').value.trim();

    if (!amount || amount <= 0 || !title || !category || !date) {
      this.showToast('Lütfen tüm zorunlu alanları doldurun.', 'error');
      return;
    }

    const payload = { type, amount, title, category, date, paymentMethod, note };

    if (editId) {
      DataManager.updateTransaction(editId, payload);
      this.showToast('İşlem başarıyla güncellendi.', 'success');
    } else {
      DataManager.addTransaction(payload);
      this.showToast('Yeni işlem başarıyla kaydedildi.', 'success');
    }

    this.closeTransactionModal();
    this.refreshAll();
  }

  static deleteTransactionConfirm(id) {
    if (confirm('Bu işlemi silmek istediğinize emin misiniz?')) {
      DataManager.deleteTransaction(id);
      this.showToast('İşlem silindi.', 'info');
      this.refreshAll();
    }
  }

  // BİRİKİM HEDEFİ İŞLEMLERİ
  static openAddSavingsModal() {
    const modal = document.getElementById('modal-savings');
    const form = document.getElementById('savings-form');
    if (form) form.reset();
    if (modal) modal.classList.remove('hidden');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }

  static closeSavingsModal() {
    const modal = document.getElementById('modal-savings');
    if (modal) modal.classList.add('hidden');
  }

  static saveSavingsGoal(e) {
    e.preventDefault();
    const title = document.getElementById('savings-title-input').value.trim();
    const target = Number(document.getElementById('savings-target-input').value);
    const current = Number(document.getElementById('savings-current-input').value) || 0;
    const deadline = document.getElementById('savings-deadline-input').value;

    if (!title || !target || !deadline) {
      this.showToast('Lütfen tüm alanları doldurun.', 'error');
      return;
    }

    DataManager.addSavingsGoal({ title, target, current, deadline });
    this.showToast('Birikim hedefi başarıyla oluşturuldu.', 'success');
    this.closeSavingsModal();
    this.refreshSavings();
  }

  static deleteSavingsGoalConfirm(id) {
    if (confirm('Bu birikim hedefini silmek istediğinize emin misiniz?')) {
      DataManager.deleteSavingsGoal(id);
      this.showToast('Birikim hedefi silindi.', 'info');
      this.refreshSavings();
    }
  }

  // HEDEFE PARA EKLE / ÇIKAR
  static openDepositModal(goalId, defaultAction = 'add') {
    const savings = DataManager.getSavings();
    const goal = savings.find(g => g.id === goalId);
    if (!goal) return;

    const modal = document.getElementById('modal-savings-deposit');
    const titleEl = document.getElementById('deposit-modal-goal-title');
    const goalIdInput = document.getElementById('deposit-goal-id');
    const amountInput = document.getElementById('deposit-amount-input');

    if (titleEl) titleEl.innerText = `${goal.title} - Para Yatır / Çek`;
    if (goalIdInput) goalIdInput.value = goalId;
    if (amountInput) amountInput.value = '';

    this.setDepositAction(defaultAction);

    if (modal) modal.classList.remove('hidden');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }

  static closeSavingsDepositModal() {
    const modal = document.getElementById('modal-savings-deposit');
    if (modal) modal.classList.add('hidden');
  }

  static setDepositAction(action) {
    this.currentDepositAction = action;
    const actionInput = document.getElementById('deposit-action-type');
    const btnAdd = document.getElementById('btn-deposit-add');
    const btnSub = document.getElementById('btn-deposit-sub');

    if (actionInput) actionInput.value = action;

    if (action === 'add') {
      btnAdd.className = 'py-1.5 rounded-lg text-xs font-bold transition bg-white text-emerald-600 shadow-sm';
      btnSub.className = 'py-1.5 rounded-lg text-xs font-bold transition text-slate-600';
    } else {
      btnSub.className = 'py-1.5 rounded-lg text-xs font-bold transition bg-white text-rose-600 shadow-sm';
      btnAdd.className = 'py-1.5 rounded-lg text-xs font-bold transition text-slate-600';
    }
  }

  static saveSavingsDeposit(e) {
    e.preventDefault();
    const goalId = document.getElementById('deposit-goal-id').value;
    const action = document.getElementById('deposit-action-type').value;
    const amount = Number(document.getElementById('deposit-amount-input').value);

    if (!amount || amount <= 0) {
      this.showToast('Geçerli bir tutar girin.', 'error');
      return;
    }

    const delta = action === 'add' ? amount : -amount;
    const updated = DataManager.updateSavingsAmount(goalId, delta);

    if (updated) {
      if (updated.current >= updated.target && typeof confetti === 'function') {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
        this.showToast(`🎉 Tebrikler! "${updated.title}" hedefinize ulaştınız!`, 'success');
      } else {
        this.showToast('Birikim tutarı güncellendi.', 'success');
      }
    }

    this.closeSavingsDepositModal();
    this.refreshSavings();
  }

  // BÜTÇE LİMİTLERİ MODALI
  static openBulkBudgetModal() {
    const modal = document.getElementById('modal-bulk-budget');
    const container = document.getElementById('bulk-budget-inputs');
    const budgets = DataManager.getBudgets();

    if (container) {
      container.innerHTML = Object.keys(CATEGORIES.expense).map(key => {
        const info = CATEGORIES.expense[key];
        const val = budgets[key] || 0;
        return `
          <div class="flex items-center justify-between gap-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100">
            <div class="flex items-center gap-2">
              <span class="w-8 h-8 rounded-lg ${info.bg} flex items-center justify-center">
                <i data-lucide="${info.icon}" class="w-4 h-4"></i>
              </span>
              <span class="text-xs font-bold text-slate-800">${info.name}</span>
            </div>
            <div class="relative w-36">
              <span class="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">₺</span>
              <input type="number" step="100" min="0" name="budget_${key}" value="${val}" class="w-full pl-6 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-right focus:ring-2 focus:ring-indigo-500">
            </div>
          </div>
        `;
      }).join('');
    }

    if (modal) modal.classList.remove('hidden');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }

  static openEditBudgetModal(catKey) {
    this.openBulkBudgetModal();
  }

  static closeBulkBudgetModal() {
    const modal = document.getElementById('modal-bulk-budget');
    if (modal) modal.classList.add('hidden');
  }

  static saveBulkBudgets(e) {
    e.preventDefault();
    const form = document.getElementById('bulk-budget-form');
    const formData = new FormData(form);
    const budgets = {};

    Object.keys(CATEGORIES.expense).forEach(key => {
      const val = formData.get(`budget_${key}`);
      budgets[key] = Number(val) || 0;
    });

    DataManager.saveBudgets(budgets);
    this.showToast('Bütçe limitleri güncellendi.', 'success');
    this.closeBulkBudgetModal();
    this.refreshAll();
  }

  // VERİ VE AYARLAR
  static resetToDemoData() {
    if (confirm('Mevcut veriler sıfırlanıp varsayılan örnek veriler yüklenecek. Emin misiniz?')) {
      DataManager.resetToDefaults();
      this.showToast('Örnek veriler başarıyla yüklendi.', 'success');
      this.refreshAll();
    }
  }

  static clearTransactionsConfirm() {
    if (confirm('Tüm kayıtlı gelir ve gider hareketleri silinecektir. Kendi işlemlerinizi girmek için temizlemek istiyor musunuz?')) {
      DataManager.clearTransactionsOnly();
      this.showToast('Tüm işlemler temizlendi. Kendi işlemlerinizi eklemeye hazırsınız!', 'success');
      this.refreshAll();
    }
  }

  static clearAllDataConfirm() {
    if (confirm('DİKKAT: Tüm işlemler, bütçeler ve birikim hedefleri silinecektir! Devam etmek istiyor musunuz?')) {
      DataManager.clearAllData();
      this.showToast('Tüm veriler temizlendi.', 'info');
      this.refreshAll();
    }
  }

  static handleImportJSON() {
    const input = document.getElementById('import-json-input');
    if (!input || !input.files || input.files.length === 0) {
      this.showToast('Lütfen önce bir JSON dosyası seçin.', 'error');
      return;
    }

    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const res = DataManager.importJSON(e.target.result);
      if (res.success) {
        this.showToast(`Yedek başarıyla yüklendi (${res.count} işlem).`, 'success');
        input.value = '';
        this.refreshAll();
      } else {
        this.showToast(`Yedek yüklenirken hata oluştu: ${res.error}`, 'error');
      }
    };

    reader.readAsText(file);
  }

  // TOAST BİLDİRİMİ
  static showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const bgColors = {
      success: 'bg-emerald-600 text-white',
      error: 'bg-rose-600 text-white',
      info: 'bg-slate-800 text-white'
    };

    const icons = {
      success: 'check-circle-2',
      error: 'alert-circle',
      info: 'info'
    };

    toast.className = `toast ${bgColors[type] || bgColors.success}`;
    toast.innerHTML = `
      <i data-lucide="${icons[type] || 'info'}" class="w-5 h-5 shrink-0"></i>
      <span class="flex-1 text-xs leading-snug">${message}</span>
    `;

    container.appendChild(toast);
    if (typeof lucide !== 'undefined') lucide.createIcons();

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
}

// Sayfa yüklendiğinde başlat
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
