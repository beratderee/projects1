/**
 * Bütçe Planlama Uygulaması - Chart.js Grafik Modülü
 */

class ChartManager {
  static expenseDonutChart = null;
  static monthlyTrendChart = null;
  static budgetComparisonChart = null;

  // Harcama Dağılımı (Doughnut Grafik)
  static renderExpenseDonut(canvasId, transactions) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    if (this.expenseDonutChart) {
      this.expenseDonutChart.destroy();
    }

    // Yalnızca giderleri filtrele
    const expenses = transactions.filter(t => t.type === 'expense');
    
    // Kategoriye göre topla
    const catTotals = {};
    expenses.forEach(t => {
      catTotals[t.category] = (catTotals[t.category] || 0) + Number(t.amount);
    });

    const sortedCategories = Object.keys(catTotals).sort((a, b) => catTotals[b] - catTotals[a]);

    if (sortedCategories.length === 0) {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }

    const labels = sortedCategories.map(cat => CATEGORIES.expense[cat]?.name || cat);
    const data = sortedCategories.map(cat => catTotals[cat]);
    const backgroundColors = sortedCategories.map(cat => CATEGORIES.expense[cat]?.color || '#94a3b8');

    const totalExpense = data.reduce((a, b) => a + b, 0);

    this.expenseDonutChart = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: backgroundColors,
          borderWidth: 2,
          borderColor: '#ffffff',
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              boxHeight: 12,
              usePointStyle: true,
              pointStyle: 'circle',
              padding: 16,
              font: {
                family: "'Inter', sans-serif",
                size: 12,
                weight: '500'
              },
              color: '#475569'
            }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            titleFont: { family: "'Inter', sans-serif", size: 13, weight: '600' },
            bodyFont: { family: "'Inter', sans-serif", size: 13 },
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: function(context) {
                const val = context.raw || 0;
                const pct = totalExpense > 0 ? ((val / totalExpense) * 100).toFixed(1) : 0;
                return ` ${context.label}: ${formatCurrency(val)} (%${pct})`;
              }
            }
          }
        }
      }
    });
  }

  // Aylık Gelir vs Gider Trendi (Bar Grafik)
  static renderMonthlyTrend(canvasId, transactions) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    if (this.monthlyTrendChart) {
      this.monthlyTrendChart.destroy();
    }

    // İşlemleri aya göre grupla (YYYY-MM)
    const monthGroups = {};

    transactions.forEach(t => {
      if (!t.date) return;
      const ym = t.date.slice(0, 7); // '2026-10'
      if (!monthGroups[ym]) {
        monthGroups[ym] = { income: 0, expense: 0 };
      }
      if (t.type === 'income') {
        monthGroups[ym].income += Number(t.amount);
      } else {
        monthGroups[ym].expense += Number(t.amount);
      }
    });

    // Ayları sırala
    const sortedMonths = Object.keys(monthGroups).sort();
    
    // Son 6 ayı al
    const displayMonths = sortedMonths.slice(-6);

    const monthNames = {
      '01': 'Ocak', '02': 'Şubat', '03': 'Mart', '04': 'Nisan',
      '05': 'Mayıs', '06': 'Haziran', '07': 'Temmuz', '08': 'Ağustos',
      '09': 'Eylül', '10': 'Ekim', '11': 'Kasım', '12': 'Aralık'
    };

    const labels = displayMonths.map(ym => {
      const [year, month] = ym.split('-');
      return `${monthNames[month] || month} ${year.slice(2)}'`;
    });

    const incomeData = displayMonths.map(ym => monthGroups[ym].income);
    const expenseData = displayMonths.map(ym => monthGroups[ym].expense);

    this.monthlyTrendChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Gelir',
            data: incomeData,
            backgroundColor: '#10b981',
            borderRadius: 8,
            maxBarThickness: 32
          },
          {
            label: 'Gider',
            data: expenseData,
            backgroundColor: '#f43f5e',
            borderRadius: 8,
            maxBarThickness: 32
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 12,
              usePointStyle: true,
              pointStyle: 'circle',
              font: { family: "'Inter', sans-serif", size: 12, weight: '500' },
              color: '#475569'
            }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: function(context) {
                return ` ${context.dataset.label}: ${formatCurrency(context.raw)}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { family: "'Inter', sans-serif", size: 12 },
              color: '#64748b'
            }
          },
          y: {
            grid: { color: '#f1f5f9' },
            ticks: {
              font: { family: "'Inter', sans-serif", size: 11 },
              color: '#94a3b8',
              callback: function(value) {
                if (value >= 1000) {
                  return (value / 1000).toFixed(0) + 'k ₺';
                }
                return value + ' ₺';
              }
            }
          }
        }
      }
    });
  }

  // Bütçe Hedefi vs Gerçekleşen (Yatay Bar Grafik)
  static renderBudgetComparison(canvasId, budgets, currentMonthExpenses) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    if (this.budgetComparisonChart) {
      this.budgetComparisonChart.destroy();
    }

    const categories = Object.keys(budgets);
    const labels = categories.map(cat => CATEGORIES.expense[cat]?.name || cat);
    const budgetAmounts = categories.map(cat => budgets[cat] || 0);
    const actualAmounts = categories.map(cat => currentMonthExpenses[cat] || 0);

    // Bütçeyi aşanları farklı renkle işaretle
    const actualColors = actualAmounts.map((actual, idx) => {
      const budget = budgetAmounts[idx];
      if (actual > budget) return '#ef4444'; // Aşım (Kırmızı)
      if (actual > budget * 0.85) return '#f59e0b'; // Yakın (Turuncu)
      return '#3b82f6'; // Normal (Mavi)
    });

    this.budgetComparisonChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Planlanan Bütçe Limiti',
            data: budgetAmounts,
            backgroundColor: '#e2e8f0',
            borderRadius: 6,
            maxBarThickness: 16
          },
          {
            label: 'Harcanan Tutar',
            data: actualAmounts,
            backgroundColor: actualColors,
            borderRadius: 6,
            maxBarThickness: 16
          }
        ]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 12,
              usePointStyle: true,
              pointStyle: 'circle',
              font: { family: "'Inter', sans-serif", size: 12, weight: '500' },
              color: '#475569'
            }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: function(context) {
                return ` ${context.dataset.label}: ${formatCurrency(context.raw)}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { color: '#f1f5f9' },
            ticks: {
              font: { family: "'Inter', sans-serif", size: 11 },
              color: '#94a3b8',
              callback: function(value) {
                if (value >= 1000) return (value / 1000).toFixed(0) + 'k ₺';
                return value + ' ₺';
              }
            }
          },
          y: {
            grid: { display: false },
            ticks: {
              font: { family: "'Inter', sans-serif", size: 12, weight: '500' },
              color: '#334155'
            }
          }
        }
      }
    });
  }
}
